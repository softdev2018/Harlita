<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class FormCobaModel extends CI_Model {
	public $nama;
	public $umur;
	public $hobi;
	public $labels = [];

	public function __construct()
	{
		parent::__construct();
		$this->labels = $this->_attribute_labels();
		$this->load->database();
	}

	private function _attribute_labels(){
		return [
			'nama' => 'Nama Kamu Gaes',
			'umur' => 'Umur Kamu Nich',
			'hobi' => 'Hobi Kamu Apa?'
		];
	}

	public function insertdata() {
		$sql = sprintf("INSERT INTO coba VALUES ('%s','%s','%s')",
			$this->nama,
			$this->umur,
			$this->hobi);
		$this->db->query($sql);
	}

	public function insert($table, $data) {
		$a = $this->db->insert($table, $data);
		return $a;
	}

}