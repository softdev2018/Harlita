<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CobaModel extends CI_Model {
	public $nama;
	public $umur;
	public $hobi;

	public $labels;
	public $elements;

	public function __construct()
	{
		parent::__construct();
		$this->labels = $this->_attribute_labels();
		$this->elements = $this->_form_element_attribute();
		$this->load->database();
	}

	//funsi untuk menampilkan semua data coba
	// public function view() {
	// 	return $this->db->get('coba');
	// }

	private function _form_element_attribute() {
		return [
			'nama'=> [
				'name' => 'nama',
				'size' => 10,
				'maxlength' => 10
			],
			'umur'=> [
				'name' => 'umur',
				'size' => 10,
				'maxlength' => 2
			],
			'hobi'=> [
				'name' => 'hobi',
				'size' => 10,
				'maxlength' => 10
			],
			];
	}

	private function _attribute_labels(){
		return [
			'nama' => 'Nama Kamu Gaes',
			'umur' => 'Umur Kamu Nich',
			'hobi' => 'Hobi Kamu Apa?'
		];
	}

	public function insertdata() {
		// $this->db->insert(); 
		$sql = sprintf("INSERT INTO coba VALUES ('%s','%s','%s')",
			$this->nama,
			$this->umur,
			$this->hobi);
		$this->db->query($sql);
	}

	public function insert($table, $data) {
		$a = $this->db->insert($table, $data);
		return $a;
	}

}