<?php

class Formsederhana extends CI_Controller {
	private $model = NULL;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('CobaModel');
		$this->model = $this->CobaModel;
		$this->load->helper('url');
		// $this->load->helper('form');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('coba/index');
	}

	public function view()
	{

		$this->load->view('coba/view_coba');
	}

	public function create()
	{
		if (isset ($_POST['btnsubmit'])) {
		$this->model->nama = $_POST['nama'];
		$this->model->umur = $_POST['umur'];
		$this->model->hobi = $_POST['hobi'];
		$this->model->insertdata();
		$this->load->view('coba/view_coba');
		} else {
			$this->load->view('coba/view_form',['model'=>$this->model]);
		}
	}

	public function create2()
	{
		if (isset ($_POST['btnsubmit'])) {
		$data = array(
				'nama' => $this->input->post('nama'),
				'umur' => $this->input->post('umur'),
				'hobi' => $this->input->post('hobi'),
		);
		$this->model->insert('coba',$data);
		$this->load->view('coba/view_coba');
		} else {
			$this->load->view('coba/view_form',['model'=>$this->model]);
		}
	}
}
