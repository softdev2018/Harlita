<?php

class FormCoba extends CI_Controller {
	private $model = NULL;

	public function __construct()
	{
		parent::__construct();
		$this->load->model('CobaModel');
		$this->model = $this->CobaModel;
		$this->load->helper('url');
		// $this->load->helper('form');
		$this->load->library('form_validation');
	}

	public function index()
        {
                $this->load->helper(array('form', 'url'));
                //load library form validasi dan membuat rules
                $this->load->library('form_validation');
                $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[10]|max_length[12]');
				$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
				$this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required|matches[password]');
				$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email',
                	array('required' => 'Email wajib diisi sesuai format, contoh email@email.com')

					);
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('formcoba/viewform');
                }
                else
                {
                        $this->load->view('formcoba/success');
                }
        }

	public function view()
	{

		$this->load->view('coba/view_coba');
	}

	public function create()
	{
		if (isset ($_POST['btnsubmit'])) {
		$this->model->nama = $_POST['nama'];
		$this->model->umur = $_POST['umur'];
		$this->model->hobi = $_POST['hobi'];
		$this->model->insertdata();
		$this->load->view('coba/view_coba');
		} else {
			$this->load->view('coba/view_form',['model'=>$this->model]);
		}
	}

	public function create2()
	{
		if (isset ($_POST['btnsubmit'])) {
		$data = array(
				'nama' => $this->input->post('nama'),
				'umur' => $this->input->post('umur'),
				'hobi' => $this->input->post('hobi'),
		);
		$this->model->insert('coba',$data);
		$this->load->view('coba/view_coba');
		} else {
			$this->load->view('coba/view_form',['model'=>$this->model]);
		}
	}
}
