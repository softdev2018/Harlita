<!DOCTYPE html>
<html>
<head>
	<title> SUKSES!!</title>
</head>
<body>
<p> SELAMAT ANDA SUKSES FORM SEDERHANA</p>
<p> FROM TANPA DATABASE </p>
Nama : 
<?php echo $model->nama ?> <br/>
Umur :
<?php echo $model->umur ?> <br/>
Hobi :
<?php echo $model->hobi ?> <br/>
</body>
</html>