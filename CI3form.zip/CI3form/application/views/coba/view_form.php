<!DOCTYPE html>
<html>
<head>
	<title> Form Sederhana </title>
</head>
<body>


</html>
<!-- <form method="post" action="http://localhost/LatihanCI3/CI3form/index.php/formsederhana/create">
<table>
	<tr>
		<td> nama </td>
		<td> : </td>
		<td> <input type="text" name="nama"/> </td>
	</tr>
		<td> umur </td>
		<td> : </td>
		<td> <input type="text" name="umur"/> <td>
	<tr> 
		<td> hobi </td>
		<td> : </td>
		<td> <input type="text" name="hobi"/> </td>
	</tr>
	<td> <input type="submit" name="btnsubmit"/> </td>
</table>
</form> -->

<?php 
echo form_open('Formsederhana/create');

echo form_label($model->labels['nama']);
echo '<br />';
echo form_input($model->elements['nama']);
echo '<br />';
echo form_label($model->labels['umur']);
echo '<br />';
echo form_input($model->elements['umur']);
echo '<br />';
echo form_label($model->labels['hobi']);
echo '<br />';
echo form_input($model->elements['hobi']);
echo '<br /><br />';

echo form_submit('btnsubmit','Kirim');
echo form_close();
?>

</body>
