<!DOCTYPE html>
<html>
<head>
	<title> Selamat Datang </title>
</head>
<body>
<p> SELAMAT DATANG DI FORMSEDERHANA INDEX</p>
<a href="<?php echo site_url('formsederhana/create'); ?>">FORM TAMBAH - create</a>
<br/> <br/>
<a href="<?php echo site_url('formsederhana/create2'); ?>">FORM TAMBAH - create2</a>
</body>
</html>